export const environment = {
  production: true,
  name: 'default',
  version: 'v1.0',
  backendServer: 'http://localhost:3000/api/ires/',
  //prod
   url : '../dist/assets/'
  // ng serve
  // url : 'assets/'
};
