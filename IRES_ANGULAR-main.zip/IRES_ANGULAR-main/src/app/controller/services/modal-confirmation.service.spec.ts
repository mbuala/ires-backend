import { TestBed } from '@angular/core/testing';

import { ModalConfirmationService } from './modal-confirmation.service';

describe('ModalConfirmationService', () => {
  let service: ModalConfirmationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModalConfirmationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
