import { Utilisateur } from './utilisateur.model';

describe('Utilisateur', () => {
  it('should create an instance', () => {
    expect(new Utilisateur()).toBeTruthy();
  });
});
