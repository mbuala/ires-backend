export class Role {
      idRole:number;
      role: String;
}
