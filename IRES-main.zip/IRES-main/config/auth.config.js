module.exports = {
    secret: "ires-secret-key",
    secretreset: "ires-secret-keyreset"
  };

  