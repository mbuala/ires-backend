# IRES BACKEND NODEJS
# APRES AVOIR CLONER LE PROJET 
# npm install: POUR L'AJOUT DES DEPENDANCES
# npm install -g sequelize-cli 
## npm install --save pg pg-hstore 
## npm install --save mysql2
# sequelize db:migrate:undo:all  OR  npx sequelize-cli  db:migrate:undo:all
# sequelize db:migrate           OR  npx sequelize-cli  db:migrate
## POUR LA MIGRATION DES TABLES VERS LA BASE DE DONNEE 
# sequelize db:seed:all      OR      npx sequelize-cli  db:seed:all
## pour ajoutés des données predefinis dans la base de données (ROLE ET ACTTIVITE)

# POUR LANCER LE SERVEUR C'EST AVEC "nodemon" OU "npm start"

# Version :
# npm 7.6.3
# Nodejs : v15.12.0
# Angular CLI: 11.2.6 
# postgresql 13.2 
# Sequelize CLI [Node: 15.12.0, CLI: 6.2.0, ORM: 6.6.2]
## git version 2.31.0.windows.1

